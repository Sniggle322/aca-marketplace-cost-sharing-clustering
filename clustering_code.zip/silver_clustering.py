import pandas as pd
pd.set_option('display.max_columns', None)
pd.set_option('display.width', 200)
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

# ============================================================
# SETTINGS: everyone should customize this section.
# ============================================================
DATA_FILE = "fl_plan_attributes_cleaned_2026.csv"

# Select assigned metal level
# ["Silver"], ["Gold"], ["Bronze", "Expanded Bronze"]
levels = ["Silver"]

# Change 'METAL' to your metal 
CSR_VARIATION_TYPES = [
    "Standard Silver On Exchange Plan",
    "Standard Silver Off Exchange Plan",
]

# Set K after reviewing the elbow plot. 
K = 4

# Choose an output filename for your assigned metal level(s).
OUTPUT_FILE = "aca_silver_cluster_results_2026.csv"

# ============================================================
# SETTINGS: end of customized section, format following comments as needed
# ============================================================

# Load the cleaned dataset
df = pd.read_csv(DATA_FILE)

# Template: 'levels' above determines which metal level(s) are included.
df = df[df["MetalLevel"].isin(levels)].copy()

# Template: the CSR filter customized for other metal levels.
if CSR_VARIATION_TYPES is not None:
    df = df[
        df["CSRVariationType"].isin(CSR_VARIATION_TYPES)
    ].copy()

# Select medical cost-sharing features
features = [
    "TEHBDedInnTier1Individual",
    "TEHBInnTier1IndividualMOOP",

    "TEHBDedInnTier2Individual",
    "TEHBInnTier2IndividualMOOP",
]

results = []

# One combined model is fitted to ALL levels selected above.
level = " + ".join(levels)

print(f"\n--- {level} ---")

# Filter plans by metal level
subset = df.copy()

# Convert features to numeric values
for col in features:
    subset[col] = pd.to_numeric(
        subset[col], errors="coerce"
    )

# Document missing values
print("\nPlans before filtering:", len(subset))

print("\nMissing values:")
print(subset[features].isna().sum())

# Remove plans missing any selected feature
subset = subset.dropna(subset=features).copy()
print("\nPlans after filtering:", len(subset))

if len(subset) < 3:
    raise ValueError("Not enough observations after filtering. Review your settings and missing values.")

# Standardize the features
X = subset[features]
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Determine possible K values
max_k = min(8, len(np.unique(X_scaled, axis=0)))

if max_k < 2:
    print("\nK-means clustering not applicable.")
    print("All remaining plans have identical cost-sharing features.")

    print("\nUnique cost-sharing combination:")
    print(X.drop_duplicates().to_string(index=False))

    subset["Cluster"] = 0

    subset.to_csv(OUTPUT_FILE, index=False)

    print(f"\nResults saved to {OUTPUT_FILE}.")
    raise SystemExit(0)

# Elbow method
inertia = []
k_values = range(1, max_k + 1)

for k in k_values:
    model = KMeans(
        n_clusters=k,
        random_state=42,
        n_init=20
    )
    model.fit(X_scaled)
    inertia.append(model.inertia_)

plt.figure(figsize=(7, 4))
plt.plot(k_values, inertia, marker="o")
plt.title(f"Elbow Method - {level}")
plt.xlabel("Number of Clusters (K)")
plt.ylabel("Within-Cluster SSE")
plt.xticks(list(k_values))
plt.grid(True)
plt.show()

# Initial choice of K = 3
# Adjust after examining the elbow plots
# Choose K based on the elbow plots
k = K
if not 2 <= k <= max_k:
    raise ValueError(f"K must be between 2 and {max_k} for the selected data; got {k}.")

kmeans = KMeans(
    n_clusters=k,
    random_state=42,
    n_init=20
)

# Assign clusters
subset["Cluster"] = kmeans.fit_predict(X_scaled)

# Display cluster sizes
print("\nCluster sizes:")
print(subset["Cluster"].value_counts().sort_index())

# Display average cost-sharing values
print("\nCluster averages:")
print(
    subset.groupby("Cluster")[features]
    .mean()
    .round(2)
)

# Display cluster centers in original units
centers = pd.DataFrame(
    scaler.inverse_transform(kmeans.cluster_centers_),
    columns=features
)

print("\nCluster centers:")
print(centers.round(2))

# Show metal-level composition when multiple levels are combined.
if len(levels) > 1:
    print("\nPlans per metal level and cluster:")
    print(pd.crosstab(subset["Cluster"], subset["MetalLevel"]))

# Scatter plot of individual plans colored by cluster
# Plot Tier 1 and Tier 2 on the same scatter plot
plt.figure(figsize=(10, 7))

for tier, marker in [(1, "o"), (2, "^")]:

    deductible = f"TEHBDedInnTier{tier}Individual"
    moop = f"TEHBInnTier{tier}IndividualMOOP"

    scatter = plt.scatter(
        subset[deductible],
        subset[moop],
        c=subset["Cluster"],
        cmap="viridis",
        vmin=0,
        vmax=k-1,
        marker=marker,
        s=75,
        alpha=0.7
    )
    # Plot cluster centers for this tier
    plt.scatter(
        centers[deductible],
        centers[moop],
        color="red",
        marker="X" if tier == 1 else "P",
        s=60,
        edgecolors="black",
        linewidths=1,
        zorder=5
    )

plt.xlabel("Individual Deductible ($)")
plt.ylabel("Individual Maximum Out-of-Pocket ($)")
plt.title(f"Tier 1 and Tier 2 Cost-Sharing - {level}")

plt.colorbar(scatter, label="Cluster", ticks=range(k))

# Legend for tier markers
tier_legend = [
    Line2D([0], [0], marker="o", color="gray",
           linestyle="None", label="Tier 1"),
    Line2D([0], [0], marker="^", color="gray",
           linestyle="None", label="Tier 2")
]

plt.legend(handles=tier_legend)
plt.grid(alpha=0.3)
plt.tight_layout()
plt.show()

results.append(subset)

# Combine results and export
if results:
    final_df = pd.concat(results)

    final_df.to_csv(
        OUTPUT_FILE,
        index=False
    )

    print(f"\nClustering results saved to {OUTPUT_FILE}.")
